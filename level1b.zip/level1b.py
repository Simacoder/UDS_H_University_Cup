import json
import sys
from megazoo_utils import parse_zoo_file

def solve_level1(input_file, output_file):
    # Parse the zoo data
    zoo_data = parse_zoo_file(input_file)

    # Get 2D coordinates of the depot
    depot = zoo_data["depot_2d"]  # (x, y)

    # Get the first food storage (2D only)
    first_storage_3d, _ = zoo_data["food_storages"][0]
    storage = (first_storage_3d[0], first_storage_3d[1])  # (x, y)

    # Create a single round trip: depot -> storage -> depot
    drone_run = [depot, storage, depot]
    runs = [drone_run]

    # Write output JSON
    with open(output_file, "w") as f:
        json.dump(runs, f, indent=4)

    print(f"Level 1: Path saved to {output_file}")


if __name__ == "__main__":
    # Usage check
    if len(sys.argv) != 3:
        print("Usage: python level1.py <input_file.json> <output_file.json>")
        sys.exit(1)

    solve_level1(sys.argv[1], sys.argv[2])
